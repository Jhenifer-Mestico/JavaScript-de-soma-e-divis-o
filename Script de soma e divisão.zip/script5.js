var x = prompt ("Digite o primeiro número");        /* soma OK*/
x = parseInt(x);
var y = prompt ("Digite o segundo número");   
y = parseInt(y);    
var z = prompt ("Digite o terceiro número");
z = parseInt(z);
resultado = (x+y+z)/3;
document.write("<p>" + resultado + "<p>"); /*comando para mostrar em parágrafo*/